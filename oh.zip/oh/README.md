Install :
$pkg update -y && pkg upgrade
$pkg Install php -y && pkg python -y
$pkg Install git -y
$python -m pip install --upgrade pip
$pip2 install requests
$pip2 install mechanize
$pip2 install bs4
$git clone https://github.com/payz404/LasDext

Usage :
$cd LasDext
$chmod +x tools.sh
$./tools.sh

[!]kalo gunain facebook checker

"$pilih : 5 -list.txt"

enjoy your day
Selamat Puasa ^-^

Thanks For 407Exploit
~Zantot Kontol