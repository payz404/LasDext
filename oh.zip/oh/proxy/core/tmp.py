R = '\033[91m'
G = '\033[92m'
B = '\033[94m'
Y = '\033[93m'
W = '\033[0m'

logo = f"""{B}
         _/_/_/         _/_/_/_/_/                          _/
       _/                  _/       _/_/        _/_/       _/
      _/  _/_/  _/_/_/    _/     _/    _/    _/    _/     _/
     _/    _/            _/     _/    _/    _/    _/     _/
      _/_/_/            _/       _/_/        _/_/       _/ {W}
                 Gretronger Tool Version{G} 4.0 unv{W}

     By       : {Y}407 AUTHENTIC EXPLOIT{W}
     Codename : {R}JaxBCD{W}
     Contact  : https://www.facebook.com/jaka.lesmana.794629
"""
menu = f'''
      {G}-1-{W} Search Proxy and Check
      {G}-2-{W} Search Host
      {G}-3-{W} Generate random Proxy
      {G}-4-{W} Check Proxy in list file
      {G}-5-{W} Check Single Proxy
      {G}-0-{W} Exit
        '''
