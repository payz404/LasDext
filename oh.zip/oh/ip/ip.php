<?php
sleep (2);
system('clear');
echo "\e[91;1m
  _   _   _   _   _
 / \ / \ / \ / \ / \
( I | P | G | e | o )
 \_/ \_/ \_/ \_/ \_/
 
\e[0m
\e[96m[~] IP Geolocation 
[~] Coded By : PayzID
[~] Facebook : https://fb.com/payz.7777\e[0m\n
";
sleep (2);
echo "\e[101;1mStarting On:\e[0m ".date("[y:m:d-h:i:sa]\n");
sleep(3);
echo "\n\e[2m[!] Example : 192.156.254.63\e[0m\n";

echo "\n\e[5m[!] Input IP Target: \e[0m";
$ip = trim(fgets(STDIN));
sleep (3);
echo "\n\e[93;1m[+] Checking Ip...\e[0m\n";
sleep (2);
 $ch = curl_init("https://extreme-ip-lookup.com/json/$ip");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_USERAGENT, "Opera/9.80 (Series 60; Opera Mini/7.0.32400/28.3445; U; en) Presto/2.8.119 Version/11.10");
   $gas = curl_exec($ch);
   $oh = json_decode($gas, TRUE);

sleep (1);
//echo $gas;
sleep (1);
echo "
\e[92;1m[+] Succes Get Info...\e[0m\n";
sleep (1);
echo "\n\e[96m--------------------------------------\e[0m";
echo "
\n\e[92;1m          [+] Result [+]\e[0m\n";
sleep (1);
//data json
echo "\n\n\e[92;1m[~] Business Name Info : " .$oh ['businessName'];
sleep (1);
echo "\n\n[+] Business Website : " .$oh ['businessWebsite'];
sleep (1);
echo "\n\n[+] City :  ".$oh['city'];
sleep (1);
echo "\n\n[+] Continent :  ".$oh['continent'];
sleep (1);
echo "\n\n[+] Country :  ".$oh['country'];
sleep (1);
echo "\n\n[+] Country Code :  ".$oh['countryCode'];
sleep (1);
echo "\n\n[+] Ip Name :  ".$oh['ipName'];
sleep (1);
echo "\n\n[+] Ip Type :  ".$oh['ipType'];
echo "\n\n[+] ISP :  ".$oh['isp'];
sleep (1);
echo "\n\n[+] Org :  ".$oh['org'];
sleep (1);
echo "\n\n[+] IP Address :  ".$oh['query'];
sleep (1);
echo "\n\n[+] Region :  ".$oh['region'];
sleep(1);
echo "\n\n[+] Status :  ".$oh['status'];
echo "\n\n\e[96m-----------------------------------\e[0m\n";
echo "
\n\e[92;1m        [+] End Result [+]\e[0m\n";
sleep (1);
echo "\n\n\e[96m-----------------------------------\e[0m";
echo "\n\n\e[91m[~] Checking Complite !\e[0m\n";
echo "\n\e[96m-----------------------------------\e[0m\n";
sleep (1);

echo "\n\e[2m[!] For More Tools Inbox My Facebook ^_^\n\e[0m\n";

/////echo json_last_error(); // 4 (JSON_ERROR_SYNTAX)
///echo json_last_error_msg(); // unexpected character 
?>