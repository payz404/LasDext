<?php
class IDsec {
	
	function emailFilter($email, $list)
	{
			// Gmail
		if (preg_match('/@gmail.co.uk/', $email)) {
			echo "\e[32;1m[Gmail.UK] \e[00;1m=> $list\n";
			$create = "Gmail[UK]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@gmail.ca/', $email)) {
			echo "\e[32;1m[Gmail.CA] \e[00;1m=> $list\n";
			$create = "Gmail[CA]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@gmail.de/', $email)) {
			echo "\e[32;1m[Gmail.DE] \e[00;1m=> $list\n";
			$create = "Gmail[DE]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@gmail.ru/', $email)) {
			echo "\e[32;1m[Gmail.RU] \e[00;1m=> $list\n";
			$create = "Gmail[RU]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@gmail.fr/', $email)) {
			echo "\e[32;1m[Gmail.FR] \e[00;1m=> $list\n";
			$create = "Gmail[FR]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@gmail.com/', $email)) {
			echo "\e[32;1m[Gmail.COM] \e[00;1m=> $list\n";
			$create = "Gmail[COM]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@gmail.co.id/', $email)) {
			echo "\e[32;1m[Gmail.ID] \e[00;1m=> $list\n";
			$create = "Gmail[ID]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@gmail.com.au/', $email)) {
			echo "\e[32;1m[Gmail.AU] \e[00;1m=> $list\n";
			$create = "Gmail[AU]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@gmail/', $email)) {
			echo "\e[32;1m[Gmail] \e[00;1m=> $list\n";
			$create = "Gmail[MIX]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
			
			// Yahoo
		}elseif (preg_match('/@yahoo.ru/', $email)) {
			echo "\e[32;1m[Yahoo.RU] \e[00;1m=> $list\n";
			$create = "Yahoo[RU]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@yahoo.co.uk/', $email)) {
			echo "\e[32;1m[Yahoo.UK] \e[00;1m=> $list\n";
			$create = "Yahoo[UK]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@yahoo.de/', $email)) {
			echo "\e[32;1m[Yahoo.DE] \e[00;1m=> $list\n";
			$create = "Yahoo[DE]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@yahoo.com/', $email)) {
			echo "\e[32;1m[Yahoo.COM] \e[00;1m=> $list\n";
			$create = "Yahoo[COM]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@yahoo.fr/', $email)) {
			echo "\e[32;1m[Yahoo.FR] \e[00;1m=> $list\n";
			$create = "Yahoo[FR]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@yahoo.co.jp/', $email)) {
			echo "\e[32;1m[Yahoo.JP] \e[00;1m=> $list\n";
			$create = "Yahoo[JP]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@yahoo.com.br/', $email)) {
			echo "\e[32;1m[Yahoo.BR] \e[00;1m=> $list\n";
			$create = "Yahoo[BR]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@yahoo.co.in/', $email)) {
			echo "\e[32;1m[Yahoo.CO.IN] \e[00;1m=> $list\n";
			$create = "Yahoo[CO.IN]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@yahoo.es/', $email)) {
			echo "\e[32;1m[Yahoo.ES] \e[00;1m=> $list\n";
			$create = "Yahoo[ES]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@yahoo.it/', $email)) {
			echo "\e[32;1m[Yahoo.IT] \e[00;1m=> $list\n";
			$create = "Yahoo[IT]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@yahoo.in/', $email)) {
			echo "\e[32;1m[Yahoo.IN] \e[00;1m=> $list\n";
			$create = "Yahoo[IN]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@yahoo.ca/', $email)) {
			echo "\e[32;1m[Yahoo.CA] \e[00;1m=> $list\n";
			$create = "Yahoo[CA]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@yahoo.com.au/', $email)) {
			echo "\e[32;1m[Yahoo.AU] \e[00;1m=> $list\n";
			$create = "Yahoo[AU]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@yahoo.com.ar/', $email)) {
			echo "\e[32;1m[Yahoo.AR] \e[00;1m=> $list\n";
			$create = "Yahoo[AR]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@yahoo.com.mx/', $email)) {
			echo "\e[32;1m[Yahoo.MX] \e[00;1m=> $list\n";
			$create = "Yahoo[MX]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@yahoo.co.id/', $email)) {
			echo "\e[32;1m[Yahoo.ID] \e[00;1m=> $list\n";
			$create = "Yahoo[ID]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@yahoo.com.sg/', $email)) {
			echo "\e[32;1m[Yahoo.SG] \e[00;1m=> $list\n";
			$create = "Yahoo[SG]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@yahoo/', $email)) {
			echo "\e[32;1m[Yahoo] \e[00;1m=> $list\n";
			$create = "Yahoo[MIX]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
			
		}elseif (preg_match('/@rocketmail/', $email)) {
			echo "\e[32;1m[Rocketmail] \e[00;1m=> $list\n";
			$create = "Rocketmail_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@ymail/', $email)) {
			echo "\e[32;1m[Ymail] \e[00;1m=> $list\n";
			$create = "Ymail_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
			
			// Yandex
		}elseif (preg_match('/@yandex.de/', $email)) {
			echo "\e[32;1m[Yandex.DE] \e[00;1m=> $list\n";
			$create = "Yandex[DE]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@yandex.com.au/', $email)) {
			echo "\e[32;1m[Yandex.AU] \e[00;1m=> $list\n";
			$create = "Yandex[AU]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@yandex.com/', $email)) {
			echo "\e[32;1m[Yandex.COM] \e[00;1m=> $list\n";
			$create = "Yandex[COm]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@yandex.co.id/', $email)) {
			echo "\e[32;1m[Yandex.ID] \e[00;1m=> $list\n";
			$create = "Yandex[ID]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@yandex.ru/', $email)) {
			echo "\e[32;1m[Yandex.RU] \e[00;1m=> $list\n";
			$create = "Yandex[RU]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@yandex.co.uk/', $email)) {
			echo "\e[32;1m[Yandex.UK] \e[00;1m=> $list\n";
			$create = "Yandex[UK]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@yandex.ca/', $email)) {
			echo "\e[32;1m[Yandex.CA] \e[00;1m=> $list\n";
			$create = "Yandex[CA]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@yandex/', $email)) {
			echo "\e[32;1m[Yandex] \e[00;1m=> $list\n";
			$create = "Yandex[MIX]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
			
			// Hotmail
		}elseif (preg_match('/@hotmail.com/', $email)) {
			echo "\e[32;1m[Hotmail.COM] \e[00;1m=> $list\n";
			$create = "Hotmail[COM]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@hotmail.co.id/', $email)) {
			echo "\e[32;1m[Hotmail.ID] \e[00;1m=> $list\n";
			$create = "Hotmail[ID]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@hotmail.co.uk/', $email)) {
			echo "\e[32;1m[Hotmail.UK] \e[00;1m=> $list\n";
			$create = "Hotmail[UK]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@hotmail.fr/', $email)) {
			echo "\e[32;1m[Hotmail.FR] \e[00;1m=> $list\n";
			$create = "Hotmail[FR]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@hotmail.ru/', $email)) {
			echo "\e[32;1m[Hotmail.RU] \e[00;1m=> $list\n";
			$create = "Hotmail[RU]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@hotmail.de/', $email)) {
			echo "\e[32;1m[Hotmail.DE] \e[00;1m=> $list\n";
			$create = "Hotmail[DE]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@hotmail.it/', $email)) {
			echo "\e[32;1m[Hotmail.IT] \e[00;1m=> $list\n";
			$create = "Hotmail[IT]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@hotmail.es/', $email)) {
			echo "\e[32;1m[Hotmail.ES] \e[00;1m=> $list\n";
			$create = "Hotmail[ES]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@hotmail/', $email)) {
			echo "\e[32;1m[Hotmail] \e[00;1m=> $list\n";
			$create = "Hotmail[MIX]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
			
			// Live
		}elseif (preg_match('/@live.com/', $email)) {
			echo "\e[32;1m[Live.COM] \e[00;1m=> $list\n";
			$create = "Live[COM]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@live.co.id/', $email)) {
			echo "\e[32;1m[Live.Id] \e[00;1m=> $list\n";
			$create = "Live[ID]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@live.de/', $email)) {
			echo "\e[32;1m[Live.DE] \e[00;1m=> $list\n";
			$create = "Live[DE]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@live.co.uk/', $email)) {
			echo "\e[32;1m[Live.CO.Uk] \e[00;1m=> $list\n";
			$create = "Live[UK]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@live.fr/', $email)) {
			echo "\e[32;1m[Live.FR] \e[00;1m=> $list\n";
			$create = "Live[FR]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@live.nl/', $email)) {
			echo "\e[32;1m[Live.NL] \e[00;1m=> $list\n";
			$create = "Live[NL]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@live.com.au/', $email)) {
			echo "\e[32;1m[Live.AU] \e[00;1m=> $list\n";
			$create = "Live[AU]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@live.ca/', $email)) {
			echo "\e[32;1m[Live.Ca] \e[00;1m=> $list\n";
			$create = "Live[CA]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@live.it/', $email)) {
			echo "\e[32;1m[Live.IT] \e[00;1m=> $list\n";
			$create = "Live[IT]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@live/', $email)) {
			echo "\e[32;1m[Live] \e[00;1m=> $list\n";
			$create = "Live[MIX]_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
			
		}elseif (preg_match('/@outlook/', $email)) {
			echo "\e[32;1m[Outlook] \e[00;1m=> $list\n";
			$create = "Outlook_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@icloud/', $email)) {
			echo "\e[32;1m[iCloud] \e[00;1m=> $list\n";
			$create = "iCloud_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@rambler/', $email)) {
			echo "\e[32;1m[Rambler] \e[00;1m=> $list\n";
			$create = "Rambler_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@mail/', $email)) {
			echo "\e[32;1m[Mail] \e[00;1m=> $list\n";
			$create = "Mail_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@aol/', $email)) {
			echo "\e[32;1m[Aol] \e[00;1m=> $list\n";
			$create = "Aol_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}elseif (preg_match('/@sky/', $email)) {
			echo "\e[32;1m[Sky] \e[00;1m=> $list\n";
			$create = "Sky_List.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}else{
			echo "\e[36;1m[Mix] \e[00;1m=> $list\n";
			$create = "Mix_List_Email.txt";
			$buat = fopen($create, 'a+');
			fwrite($buat, $list."\n");
			fclose($buat);
		}
	}
	
	public function message($maillist)
	{
		$getFile = file_get_contents($maillist);
		$pisah = explode("\r\n", $getFile);
		foreach ($pisah as $list) {
			$email = $list;
			$execution = $this->emailFilter($email, $list);
			//print_r($email);
			echo $execution;
		}
	}
}
system('clear');
$idsec = new IDsec();
echo "\e[92;1m
  _   _   _   _   _
 / \ / \ / \ / \ / \
( M | a | i | l | F )
 \_/ \_/ \_/ \_/ \_/
 
[~]Coded By : LasDex
[~]Facebook : https://fb.com/payz.7777\n
";
sleep(3);
echo "\n\e[101;1mStarting On\e[0m\n".date("h:i:sa\n");
sleep(4);
echo "\e[92;1mInput Your List :\e[1m ";
$jancok = trim(fgets(STDIN, 1024));
sleep(3);
$cekFile = file_exists($jancok);
if ($cekFile == 1) {
	echo "\e[42;1m[!] Filter Email [!]\e[0m\n";
	sleep(5);
	$idsec->message($jancok);
}else{
	echo "\e[31;1mFile notfound\e[;1m\n";
}