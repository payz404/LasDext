<?php
sleep (2);
system('clear');
echo "\e[91;1m

 _         __
|_)o_|_|  (_ |_  _ .__|_
|_)| |_|\/__)| |(_)|  |_
        /
\e[0m
\e[96m[~]Bitly ShortLink 
[~]Coded By : PayzID
[~]Facebook : https://fb.com/payz.7777\e[0m\n
";
sleep (2);
echo "\e[101;1mStarting On:\e[0m ".date("[y:m:d-h:i:sa]\n");
sleep(3);
$token="3010c8116c21562c6d3162ae137b5f8c1c20bde3";
$username="payz";
echo "\n\e[2m[!]Example https://payz404.blogspot.com\e[0m\n";

echo "\n\e[5m[!]Input Your Url: \e[0m";
$lurl = trim(fgets(STDIN));
sleep (3);
echo "\n\e[93;1m[+] URL Shortening Started...\e[0m\n";
sleep (2);
 $ch = curl_init("https://api-ssl.bitly.com/v3/shorten?access_token=$token&login=$username&longUrl=$lurl");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_USERAGENT, "Opera/9.80 (Series 60; Opera Mini/7.0.32400/28.3445; U; en) Presto/2.8.119 Version/11.10");
   $gas = curl_exec($ch);
   $oh = json_decode($gas, TRUE);
sleep (1);
//echo $gas;
echo "
\n\e[91;1m[+] Connecting...\e[0m\n";
sleep (2);
echo "
\n\e[92;1m[+] Short Succes...\e[1m\n";
sleep (1);
echo "\n[~]Status : " .$oh ['status_code'];
sleep (1);
echo "\n[~]Status txt : " .$oh ['status_txt'];
sleep (1);
echo "\n[+]Url :  ".$oh['data']['url'];
sleep (1);
echo "\n[~]Hash :  ".$oh['data']['hash'];
sleep (1);
echo "\n[~]Global_hash :  ".$oh['data']['global_hash'];
sleep (1);
echo "\n[!]Your Url :  ".$oh['data']['long_url'];
sleep (1);
echo "\n[~]New Hash :  ".$oh['data']['new_hash'];
sleep (1);
echo "\nSucces Shortening\n\e[0m\n";

echo "\n\e[2m[!]For More Token Inbox My Facebook ^_^\n\e[0m\n";


/////echo json_last_error(); // 4 (JSON_ERROR_SYNTAX)
///echo json_last_error_msg(); // unexpected character 
?>